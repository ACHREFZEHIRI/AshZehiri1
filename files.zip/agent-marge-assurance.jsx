import React, { useState, useCallback, useRef, useEffect } from "react";
import * as XLSX from "xlsx";
import {
  Upload, CheckCircle2, AlertTriangle, XCircle, ArrowRight, Loader2,
  Sparkles, RotateCcw, ShieldCheck, GitMerge, FileText, TrendingDown,
  TrendingUp, Wallet, ScanSearch, Wrench
} from "lucide-react";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend,
} from "recharts";

/* ---------- Design tokens ----------
  Background #0B0D12  panel #12151C  panel-2 #171B24  border #232838
  text #E7EAF2  muted #8891A6
  accent (pipeline indigo) #7C83FD
  signal ok #4ADE9A  warn #F5B942  error #F1655C
  mono: JetBrains Mono, body: Inter
------------------------------------- */

// Variantes réelles observées dans TB_DE_MARGE -> nom canonique
const ASSURANCE_MAP = {
  "STAR": "STAR",
  "MAE": "MAE",
  "ATTAKAFULIA": "ATTAKAFULIA", "AT-TAKAFULIA": "ATTAKAFULIA", "ATAKAFULIA": "ATTAKAFULIA",
  "EL AMANA TAKAFUL": "EL AMANA TAKAFUL", "ELAMANA TAKAFUL": "EL AMANA TAKAFUL",
  "EL AMENA TAKAFUL": "EL AMANA TAKAFUL", "AL AMENA TAKAFUL": "EL AMANA TAKAFUL",
  "ASTREE": "ASTREE", "ASTRRE": "ASTREE", "ASTRE": "ASTREE",
  "AL BARAKA": "AL BARAKA", "ALBARAKA": "AL BARAKA", "EL BARAKA": "AL BARAKA", "EL BARKA": "AL BARAKA",
  "HORS PEC": "HORS PEC", "H PEC": "HORS PEC", "HPEC": "HORS PEC", "HOES PEC": "HORS PEC",
  "HORS PEDC": "HORS PEC", "DS HORS PEC": "HORS PEC", "DS HPEC": "HORS PEC", "DS H PEC": "HORS PEC",
  "DOSSIER HORS PEC": "HORS PEC", "DS HORS PEC(AVEC REMISE)": "HORS PEC",
  "PASSAGER": "PASSAGER",
};
const INVALID_ENTRIES = ["SEAT"]; // marque confondue avec assureur, à exclure

function computeHash(r) {
  return r.dossier
    ? ["D", r.mois, canon(r.assuranceRaw || r.assurance), norm(r.dossier)].join("|")
    : ["C", r.mois, canon(r.assuranceRaw || r.assurance), r.garantie, r.immat, r.mtFactureAvant, r.mtFactureApres].join("|");
}

const norm = (s) => (s ?? "").toString().trim().toUpperCase().replace(/\s+/g, " ");
const canon = (raw) => ASSURANCE_MAP[norm(raw)] || norm(raw);
const num = (v) => (typeof v === "number" && isFinite(v) ? v : null);

function parseWorkbook(arrayBuffer) {
  const wb = XLSX.read(arrayBuffer, { type: "array" });
  const monthSheets = wb.SheetNames.filter((name) => {
    const sheet = wb.Sheets[name];
    const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: null, range: 0 });
    return rows.slice(0, 6).some((r) => r && norm(r[0]) === "ASSURANCE");
  });

  const rows = [];
  const skippedSheets = [];
  monthSheets.forEach((name) => {
    const sheet = wb.Sheets[name];
    const grid = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: null });
    const headerIdx = grid.findIndex((r) => r && norm(r[0]) === "ASSURANCE");
    if (headerIdx < 0) { skippedSheets.push(name); return; }
    for (let i = headerIdx + 1; i < grid.length; i++) {
      const r = grid[i];
      if (!r || !r[0] || typeof r[0] !== "string") continue; // saute les lignes séparatrices / vides
      const assuranceRaw = r[0];
      const mtFactureAvant = num(r[7]);
      const mtFactureApres = num(r[12]);
      if (mtFactureAvant === null && mtFactureApres === null) continue;
      rows.push({
        mois: name,
        assuranceRaw,
        assurance: canon(assuranceRaw),
        garantie: r[1] || null,
        dossier: r[2] || null,
        immat: r[3] || null,
        marque: r[4] ? norm(r[4]) : null,
        adherent: r[5] || null,
        cfeur: r[6] || null,
        mtFactureAvant, moAvant: num(r[8]), piecesAvant: num(r[9]), pdtAvant: num(r[10]),
        mtFactureApres, moApres: num(r[13]), piecesApres: num(r[14]), pdtApres: num(r[15]),
        margeMo: num(r[17]), margePieces: num(r[18]), margeTotale: num(r[19]), margePdt: num(r[20]),
      });
    }
  });
  // Vérification et correction du total = MO + Pièces (le total facturé/validé doit être la somme
  // de la main d'œuvre et des pièces). Quand ce n'est pas le cas, on corrige en utilisant MO+Pièces,
  // qui s'est révélé fiable à >99.9% sur l'historique, et on garde l'original pour audit.
  rows.forEach((r) => {
    r.mtFactureAvantOriginal = r.mtFactureAvant;
    r.mtFactureApresOriginal = r.mtFactureApres;
    r.totalCorrige = false;
    r.totalEcartAvant = null;
    r.totalEcartApres = null;
    if (r.moAvant != null && r.piecesAvant != null && r.mtFactureAvant != null) {
      const recalc = r.moAvant + r.piecesAvant;
      const ecart = recalc - r.mtFactureAvant;
      if (Math.abs(ecart) > 0.5) {
        r.totalEcartAvant = ecart;
        r.mtFactureAvant = recalc;
        r.totalCorrige = true;
      }
    }
    if (r.moApres != null && r.piecesApres != null && r.mtFactureApres != null) {
      const recalc = r.moApres + r.piecesApres;
      const ecart = recalc - r.mtFactureApres;
      if (Math.abs(ecart) > 0.5) {
        r.totalEcartApres = ecart;
        r.mtFactureApres = recalc;
        r.totalCorrige = true;
      }
    }
  });
  // Vérification de la marge pièces : formule = (pièces vente - pièces achat) / pièces achat x 100
  rows.forEach((r) => {
    if (r.piecesAvant != null && r.piecesApres != null && r.piecesApres !== 0) {
      r.margePiecesRecalc = ((r.piecesAvant - r.piecesApres) / r.piecesApres) * 100;
      r.margePiecesEcart = r.margePieces != null ? r.margePiecesRecalc - r.margePieces : null;
    } else {
      r.margePiecesRecalc = null;
      r.margePiecesEcart = null;
    }
    if (r.margePieces != null && (r.piecesAvant == null || r.piecesApres == null)) {
      r.margeAlert = "non_verifiable";
    } else if (r.margePieces != null && (r.margePieces > 150 || r.margePieces < -20)) {
      r.margeAlert = "extreme";
    } else {
      r.margeAlert = null;
    }
  });
  rows.forEach((r) => {
    r.__hash = computeHash(r);
  });
  return { rows, monthSheets, skippedSheets };
}

async function askClaude(prompt) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  const data = await res.json();
  return (data.content || []).map((b) => b.text || "").join("\n");
}

const STEPS = [
  { key: "upload", label: "Import" },
  { key: "quality", label: "Contrôle qualité" },
  { key: "merge", label: "Fusion" },
  { key: "report", label: "Rapport" },
];

const fmt = (n) => (n == null ? "—" : n.toLocaleString("fr-FR", { maximumFractionDigits: 0 }));

export default function MargeAssuranceAgent() {
  const [stepIdx, setStepIdx] = useState(0);
  const [fileName, setFileName] = useState("");
  const [parsed, setParsed] = useState(null);
  const [issues, setIssues] = useState({ duplicates: [], missing: [], invalid: [], margeAlerts: [], totalCorrections: [] });
  const [history, setHistory] = useState([]);
  const [historyLoaded, setHistoryLoaded] = useState(false);
  const [mergePreview, setMergePreview] = useState({ added: 0, skipped: 0 });
  const [report, setReport] = useState("");
  const [loadingReport, setLoadingReport] = useState(false);
  const [error, setError] = useState("");
  const fileInput = useRef(null);
  const storageKey = "wf-marge-assurance-history";

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get(storageKey);
        const loaded = res ? JSON.parse(res.value) : [];
        // Recalcule le hash de chaque enregistrement stocké avec la formule de fusion
        // actuelle (dossier+assureur+mois), pour rester compatible avec un historique
        // sauvegardé par une version antérieure de l'agent et éviter les doublons.
        loaded.forEach((r) => { r.__hash = computeHash(r); });
        setHistory(loaded);
      } catch {
        setHistory([]);
      }
      setHistoryLoaded(true);
    })();
  }, []);

  const reset = () => {
    setStepIdx(0); setFileName(""); setParsed(null);
    setIssues({ duplicates: [], missing: [], invalid: [], margeAlerts: [], totalCorrections: [] });
    setMergePreview({ added: 0, skipped: 0 }); setReport(""); setError("");
  };

  const handleFile = useCallback((file) => {
    setError("");
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const result = parseWorkbook(e.target.result);
        if (!result.rows.length) {
          setError("Aucune ligne exploitable trouvée. Vérifie que le fichier contient bien des onglets avec un en-tête 'ASSURANCE'.");
          return;
        }
        setParsed(result);

        const seen = new Set();
        const duplicates = [];
        const missing = [];
        const invalid = [];
        const margeAlerts = [];
        const totalCorrections = [];
        result.rows.forEach((r, i) => {
          if (seen.has(r.__hash)) duplicates.push(i); else seen.add(r.__hash);
          if (!r.dossier || (r.mtFactureAvant === null && r.mtFactureApres === null)) missing.push(i);
          if (INVALID_ENTRIES.includes(r.assurance)) invalid.push(i);
          if (r.margeAlert) margeAlerts.push(i);
          if (r.totalCorrige) totalCorrections.push(i);
        });
        setIssues({ duplicates: [...new Set(duplicates)], missing: [...new Set(missing)], invalid: [...new Set(invalid)], margeAlerts: [...new Set(margeAlerts)], totalCorrections: [...new Set(totalCorrections)] });
        setStepIdx(1);
      } catch (err) {
        setError("Impossible de lire ce fichier. Vérifie qu'il s'agit bien d'un .xlsx valide au format TB_DE_MARGE.");
      }
    };
    reader.readAsArrayBuffer(file);
  }, []);

  const goMerge = () => {
    const existingHashes = new Set(history.map((h) => h.__hash));
    const cleanRows = parsed.rows.filter((r, i) => !issues.invalid.includes(i) && !issues.duplicates.includes(i));
    const toAdd = cleanRows.filter((r) => !existingHashes.has(r.__hash));
    setMergePreview({ added: toAdd.length, skipped: cleanRows.length - toAdd.length });
    setStepIdx(2);
  };

  const confirmMerge = async () => {
    const existingHashes = new Set(history.map((h) => h.__hash));
    const cleanRows = parsed.rows.filter((r, i) => !issues.invalid.includes(i) && !issues.duplicates.includes(i));
    const toAdd = cleanRows.filter((r) => !existingHashes.has(r.__hash));
    const merged = [...history, ...toAdd];
    try {
      await window.storage.set(storageKey, JSON.stringify(merged));
      setHistory(merged);
      setStepIdx(3);
      generateReport(merged, toAdd);
    } catch {
      setError("Échec de l'enregistrement dans le stockage.");
    }
  };

  const generateReport = async (merged, added) => {
    setLoadingReport(true);
    setReport("");
    try {
      const byAss = {};
      merged.forEach((r) => {
        const k = r.assurance;
        byAss[k] = byAss[k] || { n: 0, avant: 0, apres: 0 };
        byAss[k].n += 1;
        byAss[k].avant += r.mtFactureAvant || 0;
        byAss[k].apres += r.mtFactureApres || 0;
      });
      const totalAvant = merged.reduce((s, r) => s + (r.mtFactureAvant || 0), 0);
      const totalApres = merged.reduce((s, r) => s + (r.mtFactureApres || 0), 0);
      const nbAlertesMarge = issues.margeAlerts ? issues.margeAlerts.length : 0;
      const nbCorrections = issues.totalCorrections ? issues.totalCorrections.length : 0;
      const summary = `Total dossiers cumulés: ${merged.length}. Nouveaux dossiers importés: ${added.length}. Montant facturé total HT: ${Math.round(totalAvant)} TND. Montant validé total HT: ${Math.round(totalApres)} TND. Écart global: ${totalAvant ? (((totalAvant - totalApres) / totalAvant) * 100).toFixed(1) : 0}%. Dossiers avec marge pièces à vérifier (non conforme ou extrême) sur cet import: ${nbAlertesMarge}. Dossiers dont le total facturé/validé a dû être corrigé (incohérent avec MO+Pièces) sur cet import: ${nbCorrections}. Répartition par assureur (dossiers, facturé, validé): ${JSON.stringify(byAss)}.`;
      const prompt = `Tu es analyste opérations pour un réparateur automobile agréé assurance en Tunisie (TND). Voici les données de marge après import mensuel:\n${summary}\nRédige un résumé exécutif en français, 4 à 6 phrases, factuel, destiné à un directeur. Mentionne l'écart facturé/validé, les assureurs les plus concentrés, le nombre de dossiers dont la marge pièces mérite une vérification manuelle, et le nombre de totaux corrigés automatiquement. Pas de préambule, pas de titre, texte brut uniquement.`;
      const text = await askClaude(prompt);
      setReport(text.trim());
    } catch {
      setReport("Le rapport n'a pas pu être généré (connexion à l'API indisponible). Les données ont bien été fusionnées dans l'historique.");
    } finally {
      setLoadingReport(false);
    }
  };

  const totalIssues = issues.duplicates.length + issues.missing.length + issues.invalid.length;

  // Dashboard data (computed after merge)
  const byAssureurData = React.useMemo(() => {
    const m = {};
    history.forEach((r) => {
      m[r.assurance] = m[r.assurance] || { assureur: r.assurance, facture: 0, valide: 0, n: 0 };
      m[r.assurance].facture += r.mtFactureAvant || 0;
      m[r.assurance].valide += r.mtFactureApres || 0;
      m[r.assurance].n += 1;
    });
    return Object.values(m).sort((a, b) => b.facture - a.facture).slice(0, 8);
  }, [history]);

  const byMoisData = React.useMemo(() => {
    const m = {};
    history.forEach((r) => {
      const label = r.mois.replace(" 2026", "");
      m[label] = m[label] || { mois: label, facture: 0, valide: 0 };
      m[label].facture += r.mtFactureAvant || 0;
      m[label].valide += r.mtFactureApres || 0;
    });
    const order = ["JANVIER","FEVRIER","MARS","AVRIL","MAI","JUIN","JUILLET","AOUT","SEPTEMBRE","OCTOBRE","NOVEMBRE","DECEMBRE"];
    return Object.values(m).sort((a, b) => order.indexOf(a.mois) - order.indexOf(b.mois));
  }, [history]);

  const kpis = React.useMemo(() => {
    const totalAvant = history.reduce((s, r) => s + (r.mtFactureAvant || 0), 0);
    const totalApres = history.reduce((s, r) => s + (r.mtFactureApres || 0), 0);
    const ecart = totalAvant ? ((totalAvant - totalApres) / totalAvant) * 100 : 0;
    return { totalAvant, totalApres, ecart, n: history.length };
  }, [history]);

  return (
    <div style={{ minHeight: "100vh", background: "#0B0D12", color: "#E7EAF2", fontFamily: "Inter, -apple-system, sans-serif", padding: "32px 20px" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap');
        * { box-sizing: border-box; }
        .mono { font-family: 'JetBrains Mono', monospace; }
        .btn { cursor: pointer; border: none; border-radius: 8px; font-weight: 600; transition: all .15s ease; font-family: inherit; }
        .btn-primary { background: #7C83FD; color: #0B0D12; padding: 11px 20px; font-size: 14px; }
        .btn-primary:hover { background: #9198FF; }
        .btn-ghost { background: transparent; color: #8891A6; padding: 10px 16px; font-size: 13px; border: 1px solid #232838; }
        .btn-ghost:hover { border-color: #7C83FD; color: #E7EAF2; }
        .panel { background: #12151C; border: 1px solid #232838; border-radius: 12px; }
        .fade-in { animation: fadeIn .35s ease; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (prefers-reduced-motion: reduce) { .fade-in { animation: none; } }
      `}</style>

      <div style={{ maxWidth: 920, margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 28 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 8, background: "#7C83FD", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Sparkles size={18} color="#0B0D12" />
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 16 }}>Agent TB de Marge Assurance</div>
              <div className="mono" style={{ fontSize: 11, color: "#565C6E" }}>import · normalisation · contrôle · fusion · rapport</div>
            </div>
          </div>
          {parsed && (
            <button className="btn btn-ghost" onClick={reset} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <RotateCcw size={13} /> Nouveau
            </button>
          )}
        </div>

        <div className="panel" style={{ padding: "18px 20px", marginBottom: 24, display: "flex", alignItems: "center" }}>
          {STEPS.map((s, i) => {
            const active = i === stepIdx;
            const done = i < stepIdx;
            return (
              <React.Fragment key={s.key}>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, minWidth: 64 }}>
                  <div style={{ width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: done ? "#4ADE9A" : active ? "#7C83FD" : "#171B24", border: active || done ? "none" : "1px solid #232838" }}>
                    {done ? <CheckCircle2 size={15} color="#0B0D12" /> : <span className="mono" style={{ fontSize: 12, color: active ? "#0B0D12" : "#565C6E" }}>{i + 1}</span>}
                  </div>
                  <span style={{ fontSize: 11, color: active ? "#E7EAF2" : "#565C6E", fontWeight: active ? 600 : 400 }}>{s.label}</span>
                </div>
                {i < STEPS.length - 1 && <div style={{ flex: 1, height: 1, background: i < stepIdx ? "#4ADE9A" : "#232838", margin: "0 4px 20px" }} />}
              </React.Fragment>
            );
          })}
        </div>

        {error && (
          <div className="panel fade-in" style={{ padding: 14, marginBottom: 16, borderColor: "#F1655C", display: "flex", gap: 10 }}>
            <XCircle size={16} color="#F1655C" style={{ flexShrink: 0, marginTop: 2 }} />
            <span style={{ fontSize: 13 }}>{error}</span>
          </div>
        )}

        {stepIdx === 0 && (
          <div className="panel fade-in" style={{ padding: 40 }}>
            <div
              onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]); }}
              onDragOver={(e) => e.preventDefault()}
              onClick={() => fileInput.current?.click()}
              style={{ border: "1.5px dashed #232838", borderRadius: 10, padding: "48px 20px", textAlign: "center", cursor: "pointer" }}
            >
              <Upload size={28} color="#7C83FD" style={{ marginBottom: 12 }} />
              <div style={{ fontWeight: 600, marginBottom: 4 }}>Dépose ton fichier TB_DE_MARGE</div>
              <div style={{ fontSize: 13, color: "#8891A6" }}>Un onglet par mois, en-tête ASSURANCE / GARANTIE / N° DOSSIER…</div>
              <input ref={fileInput} type="file" accept=".xlsx,.xls" style={{ display: "none" }} onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])} />
            </div>
            {historyLoaded && history.length > 0 && (
              <div className="mono" style={{ fontSize: 12, color: "#565C6E", marginTop: 18, textAlign: "center" }}>
                Historique déjà enregistré : {history.length} dossiers
              </div>
            )}
          </div>
        )}

        {stepIdx === 1 && parsed && (
          <div className="panel fade-in" style={{ padding: 28 }}>
            <div style={{ fontWeight: 600, marginBottom: 4 }}>Contrôle qualité</div>
            <div className="mono" style={{ fontSize: 12, color: "#565C6E", marginBottom: 20 }}>
              {fileName} · {parsed.monthSheets.length} onglets mensuels · {parsed.rows.length} dossiers
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr 1fr", gap: 10, marginBottom: 22 }}>
              {[
                { label: "Doublons", n: issues.duplicates.length, icon: AlertTriangle, color: "#F5B942" },
                { label: "Champs manquants", n: issues.missing.length, icon: AlertTriangle, color: "#F5B942" },
                { label: "Entrées invalides", n: issues.invalid.length, icon: XCircle, color: "#F1655C" },
                { label: "Marges pièces à vérifier", n: issues.margeAlerts.length, icon: ScanSearch, color: "#F5B942" },
                { label: "Totaux corrigés (MO+Pièces)", n: issues.totalCorrections.length, icon: Wrench, color: "#F5B942" },
              ].map((c) => (
                <div key={c.label} style={{ background: "#171B24", borderRadius: 10, padding: 16 }}>
                  <c.icon size={15} color={c.n > 0 ? c.color : "#4ADE9A"} />
                  <div className="mono" style={{ fontSize: 26, fontWeight: 700, marginTop: 8 }}>{c.n}</div>
                  <div style={{ fontSize: 12, color: "#8891A6" }}>{c.label}</div>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 13, color: "#8891A6", marginBottom: 20, lineHeight: 1.6 }}>
              Les noms d'assureurs ont été normalisés automatiquement (ex. AT-TAKAFULIA / ATAKAFULIA → ATTAKAFULIA).
              Les entrées invalides (ex. {INVALID_ENTRIES.join(", ")}, confondues avec une marque) et les doublons seront exclus de la fusion.
              La marge pièces est recalculée ({"(vente − achat) / achat × 100"}) et comparée à la valeur du fichier.
              Le total facturé/validé doit être égal à MO + Pièces ({"Total = MO HT + Pièces HT"}) : quand ce n'est pas le cas, le total est automatiquement corrigé avec MO+Pièces (l'original reste consultable) avant la fusion.
            </div>

            {issues.totalCorrections.length > 0 && (
              <div style={{ marginBottom: 20 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                  <Wrench size={14} color="#F5B942" /> Totaux corrigés ({issues.totalCorrections.length})
                </div>
                <div style={{ maxHeight: 220, overflowY: "auto", border: "1px solid #232838", borderRadius: 10 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                    <thead>
                      <tr style={{ background: "#171B24", position: "sticky", top: 0 }}>
                        {["Mois", "Assureur", "Dossier", "Côté", "Total original", "MO+Pièces (corrigé)", "Écart"].map((h) => (
                          <th key={h} style={{ textAlign: "left", padding: "8px 10px", color: "#8891A6", fontWeight: 600 }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {issues.totalCorrections.map((i) => {
                        const r = parsed.rows[i];
                        const items = [];
                        if (r.totalEcartAvant != null) items.push({ cote: "Facturé", orig: r.mtFactureAvantOriginal, corr: r.mtFactureAvant, ecart: r.totalEcartAvant });
                        if (r.totalEcartApres != null) items.push({ cote: "Validé", orig: r.mtFactureApresOriginal, corr: r.mtFactureApres, ecart: r.totalEcartApres });
                        return items.map((it, j) => (
                          <tr key={i + "-" + j} className="row-hover" style={{ borderTop: "1px solid #1c2130" }}>
                            <td className="mono" style={{ padding: "7px 10px" }}>{r.mois.replace(" 2026", "")}</td>
                            <td style={{ padding: "7px 10px" }}>{r.assurance}</td>
                            <td className="mono" style={{ padding: "7px 10px" }}>{r.dossier || "—"}</td>
                            <td style={{ padding: "7px 10px" }}>{it.cote}</td>
                            <td className="mono" style={{ padding: "7px 10px", color: "#8891A6" }}>{fmt(it.orig)}</td>
                            <td className="mono" style={{ padding: "7px 10px" }}>{fmt(it.corr)}</td>
                            <td className="mono" style={{ padding: "7px 10px", color: "#F5B942" }}>{fmt(it.ecart)}</td>
                          </tr>
                        ));
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {issues.margeAlerts.length > 0 && (
              <div style={{ marginBottom: 20 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                  <ScanSearch size={14} color="#F5B942" /> Dossiers à vérifier ({issues.margeAlerts.length})
                </div>
                <div style={{ maxHeight: 260, overflowY: "auto", border: "1px solid #232838", borderRadius: 10 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                    <thead>
                      <tr style={{ background: "#171B24", position: "sticky", top: 0 }}>
                        {["Mois", "Assureur", "Dossier", "Vente HT", "Achat HT", "Marge fichier", "Marge recalc.", "Statut"].map((h) => (
                          <th key={h} style={{ textAlign: "left", padding: "8px 10px", color: "#8891A6", fontWeight: 600 }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {issues.margeAlerts
                        .map((i) => parsed.rows[i])
                        .sort((a, b) => Math.abs(b.margePieces || 0) - Math.abs(a.margePieces || 0))
                        .slice(0, 30)
                        .map((r, idx) => (
                          <tr key={idx} className="row-hover" style={{ borderTop: "1px solid #1c2130" }}>
                            <td className="mono" style={{ padding: "7px 10px" }}>{r.mois.replace(" 2026", "")}</td>
                            <td style={{ padding: "7px 10px" }}>{r.assurance}</td>
                            <td className="mono" style={{ padding: "7px 10px" }}>{r.dossier || "—"}</td>
                            <td className="mono" style={{ padding: "7px 10px" }}>{fmt(r.piecesAvant)}</td>
                            <td className="mono" style={{ padding: "7px 10px" }}>{fmt(r.piecesApres)}</td>
                            <td className="mono" style={{ padding: "7px 10px", color: r.margeAlert === "extreme" ? "#F5B942" : "#F1655C" }}>
                              {r.margePieces != null ? r.margePieces.toFixed(1) + "%" : "—"}
                            </td>
                            <td className="mono" style={{ padding: "7px 10px" }}>
                              {r.margePiecesRecalc != null ? r.margePiecesRecalc.toFixed(1) + "%" : "—"}
                            </td>
                            <td style={{ padding: "7px 10px", fontSize: 11, color: "#8891A6" }}>
                              {r.margeAlert === "non_verifiable" ? "Donnée manquante" : "Marge extrême"}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <button className="btn btn-primary" onClick={goMerge} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              Continuer vers la fusion <ArrowRight size={14} />
            </button>
          </div>
        )}

        {stepIdx === 2 && (
          <div className="panel fade-in" style={{ padding: 28 }}>
            <div style={{ fontWeight: 600, marginBottom: 6 }}>Fusion avec l'historique</div>
            <div style={{ fontSize: 13, color: "#8891A6", marginBottom: 20 }}>
              Historique actuel : <span className="mono">{history.length}</span> dossiers
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 24 }}>
              <div style={{ background: "#171B24", borderRadius: 10, padding: 16 }}>
                <div className="mono" style={{ fontSize: 26, fontWeight: 700, color: "#4ADE9A" }}>+{mergePreview.added}</div>
                <div style={{ fontSize: 12, color: "#8891A6" }}>nouveaux dossiers à ajouter</div>
              </div>
              <div style={{ background: "#171B24", borderRadius: 10, padding: 16 }}>
                <div className="mono" style={{ fontSize: 26, fontWeight: 700, color: "#565C6E" }}>{mergePreview.skipped}</div>
                <div style={{ fontSize: 12, color: "#8891A6" }}>déjà présents (ignorés)</div>
              </div>
            </div>
            <button className="btn btn-primary" onClick={confirmMerge} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <GitMerge size={14} /> Confirmer la fusion
            </button>
          </div>
        )}

        {stepIdx === 3 && (
          <div className="fade-in">
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 16 }}>
              {[
                { label: "Dossiers cumulés", val: fmt(kpis.n), icon: FileText },
                { label: "Facturé HT (TND)", val: fmt(kpis.totalAvant), icon: Wallet },
                { label: "Validé HT (TND)", val: fmt(kpis.totalApres), icon: TrendingUp },
                { label: "Écart moyen", val: kpis.ecart.toFixed(1) + "%", icon: TrendingDown },
              ].map((k) => (
                <div key={k.label} className="panel" style={{ padding: 16 }}>
                  <k.icon size={14} color="#7C83FD" />
                  <div className="mono" style={{ fontSize: 20, fontWeight: 700, marginTop: 8 }}>{k.val}</div>
                  <div style={{ fontSize: 11, color: "#8891A6" }}>{k.label}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
              <div className="panel" style={{ padding: 18 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#8891A6", marginBottom: 12 }}>Facturé vs validé par assureur</div>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={byAssureurData} margin={{ left: -20 }}>
                    <CartesianGrid stroke="#232838" vertical={false} />
                    <XAxis dataKey="assureur" tick={{ fill: "#8891A6", fontSize: 10 }} interval={0} angle={-30} textAnchor="end" height={60} />
                    <YAxis tick={{ fill: "#8891A6", fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: "#171B24", border: "1px solid #232838", borderRadius: 8, fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="facture" name="Facturé" fill="#7C83FD" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="valide" name="Validé" fill="#4ADE9A" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="panel" style={{ padding: 18 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#8891A6", marginBottom: 12 }}>Évolution mensuelle</div>
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart data={byMoisData} margin={{ left: -20 }}>
                    <CartesianGrid stroke="#232838" vertical={false} />
                    <XAxis dataKey="mois" tick={{ fill: "#8891A6", fontSize: 10 }} />
                    <YAxis tick={{ fill: "#8891A6", fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: "#171B24", border: "1px solid #232838", borderRadius: 8, fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Line type="monotone" dataKey="facture" name="Facturé" stroke="#7C83FD" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="valide" name="Validé" stroke="#4ADE9A" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="panel" style={{ padding: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: "#8891A6", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                <FileText size={14} /> Résumé exécutif
              </div>
              {loadingReport ? (
                <div style={{ display: "flex", alignItems: "center", gap: 8, color: "#8891A6", fontSize: 13, padding: "16px 0" }}>
                  <Loader2 size={15} style={{ animation: "spin 1s linear infinite" }} /> Génération du rapport...
                </div>
              ) : (
                <div style={{ background: "#171B24", borderRadius: 10, padding: 18, fontSize: 14, lineHeight: 1.7 }}>{report}</div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
